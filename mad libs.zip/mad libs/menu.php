<div class='nav'>
	<ul>
		<li><a href="paniek.php">Paniek</a></li>
		<li><a href="onkunde.php">Onkunde</a></li>
	</ul>
</div>