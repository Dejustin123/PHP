<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id='container'>
		<?php require "menu.php"; ?>
		<?php require "footer.php"; ?>
	</div>
</body>
</html>