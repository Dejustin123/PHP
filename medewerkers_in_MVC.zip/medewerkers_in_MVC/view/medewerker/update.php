<h1>Persoon wijzigen</h1>
 <form name="update" method="post" action="<?=URL?>medewerker/update">
    <input type="hidden" name="id" value="<?=$data["id"] ?>"/>
    <!--  Bouw hier de rest van je formulier   -->
</form>