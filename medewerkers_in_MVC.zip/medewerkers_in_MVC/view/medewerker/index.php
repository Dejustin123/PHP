<h1>Overzicht van personen</h1>

<?php

// maak een overzicht lijst van ALLE personen
$eersteMedewerker= $data[0];
echo "<ul>";
printf("<li>");

// %s en %u zijn variables die na de comma gevuld worden met waarden (op volgorde)
printf("<span>%s is %u jaar</span>", $eersteMedewerker["name"], $eersteMedewerker["age"]);

// de opbouw van de link bepaald welke functie in welke controller aangeroepen wordt.
// het woordje "medewerker" in de url betekent dat het framework moet zoeken naar een controller genaamd "MedewerkerController".
// Hij maakt van de eerste letter een hoofdletter en plakt er zelf "Controller" achter.
// Het woordje "update" of "delete" betekent dat hij in deze controller moet zoeken naar een functie met deze naam.
printf("<a href=\"%smedewerker/update/%u\">wijzigen</a> <a href=\"%smedewerker/delete/%u\">verwijderen</a>", URL, $eersteMedewerker["id"], URL, $eersteMedewerker["id"]);

printf("</li>");
echo "</ul>";
?>
