<?php

function getAllMedewerkers(){
   try {
       //open de connectie met de database
       $conn=openDatabaseConnection();

       $result;

       // set the PDO error mode to exception
       $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
       // prepare a statement (query)
       $stmt = $conn->prepare("SELECT * FROM medewerkers");
       // execute the statement
       $stmt->execute();
       // fetch the result
       $result = $stmt->fetchAll();

   }
   catch(PDOException $e){
       // error message
       echo "Connection failed: " . $e->getMessage();
   }
   // close the connection to the database
   $conn = null;
   //return the result
   return $result;
}

function getMedewerker($id){
    try {
        //open de connectie met de database
        $conn=openDatabaseConnection();
        $result;
 
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        // prepare a statement (query)
        $stmt = $conn->prepare("SELECT * FROM users WHERE id=:id");
        // bind a parameter
        $stmt->bindParam(":id", $id);
        // execute a query
        $stmt->execute();
        // fetch the data
        $result = $stmt->fetch();
 
    }
    catch(PDOException $e){
        // error message
        echo "Connection failed: " . $e->getMessage();
    }
    // close the connection
    $conn = null;
    // return the result
    return $result;
 }

function createMedewerker($data){
    // code to create a person here...

 }


 function updateMedewerker($data){
    // code to update a person here
 }

 function deleteMedewerker($id){
    // code to delete a person here
 }


?>