<?php
require(ROOT . "model/MedewerkerModel.php");


function index()
{
    //1. Haal alle medewerkers op uit de database (via de model) en sla deze op in een variable
    $medewerkers = getAllMedewerkers();
    //2. Geef een view weer en geef de variable met medewerkers hieraan mee
    render('medewerker/index', $medewerkers);
}

function create(){
    //1. Geef een view weer waarin een formulier staat voor het aanmaken van een medewerker

}

function store(){
    //1. Maak een nieuwe medewerker aan met de data uit het formulier en sla deze op in de database

    //2. Bouw een url op en redirect hierheen

}

function update($id){
    //1. Haal een medewerker op met een specifiek id en sla deze op in een variable

    //2. Geef een view weer voor het updaten en geef de variable met medewerker hieraan mee

}

function patch(){
    //1. Update een bestaand persoon met de data uit het formulier en sla deze op in de database

    //2. Bouw een url en redirect hierheen

}

function delete($id){
    //1. Haal een medewerker op met een specifiek id en sla deze op in een variable

    //2. Geef een view weer voor het verwijderen en geef de variable met medewerker hieraan mee

}

function destroy($id){
    //1. Delete een medewerker uit de database

	//2. Bouw een url en redirect hierheen
    
}





/* server-sided check on required fields */
function createActionRequired(){
	$fieldNames=["name", "age"];
    $fieldValues=[];
	$fieldErrors=[];
	
	foreach($fieldNames as $fieldname){
		if (empty($_POST[$fieldname])) {// if field is empty then set error message
			 $fieldErrors[$fieldname] = "<i class=\"fas fa-exclamation-triangle\"></i>";
		 }
		 else { // if field is not empty then set fieldValue
			 $fieldValues[$fieldname] =  test_input($_POST[$fieldname]);
		 } 
	}

	$data['values']=$fieldValues;
	$data['errors']=$fieldErrors;

	if(sizeof($data['errors']) > 0)
		render("medewerker/create", $data);
	else{
		$result = createPerson($_POST);
		$url = URL . "medewerker/index";
    	header("refresh:0; $url");
	}
}


?>